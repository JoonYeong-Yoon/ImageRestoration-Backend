DB_CONFIG = {
    "host": "192.168.0.9",
    "port": 3307, 
    "user": "root",
    "password": "1234",
    "database": "rememory_db",
    "charset": "utf8mb4"
}

SECRET_KEY = "super_secret_key"


# ---- DB 연결 정보 (환경에 맞게 수정) ----
